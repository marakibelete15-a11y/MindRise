// ===============================
// MINDRISE FRONTEND INTERACTIONS
// ===============================


// Display a message on the screen.
function showMessage(message) {
    const oldToast = document.querySelector(".toast");

    if (oldToast) {
        oldToast.remove();
    }

    const toast = document.createElement("div");

    toast.className = "toast";
    toast.setAttribute("role", "status");
    toast.textContent = message;

    document.body.appendChild(toast);

    setTimeout(() => {
        toast.remove();
    }, 2800);
}


// ===============================
// DAILY ROUTINES
// ===============================

const routineItems = document.querySelectorAll(".routine-item");

function updateRoutine(item) {
    const checkbox = item.querySelector("input");
    const status = item.querySelector(".routine-status");

    item.classList.toggle("completed", checkbox.checked);

    status.textContent = checkbox.checked ? "Done" : "Pending";
}

routineItems.forEach((item) => {
    const checkbox = item.querySelector("input");

    checkbox.addEventListener("change", () => {
        updateRoutine(item);

        const routineName =
            item.querySelector(".routine-name").textContent.trim();

        if (checkbox.checked) {
            showMessage("Great job! Routine completed 🌿");
        } else {
            showMessage("Routine marked as pending.");
        }
    });

    // Ensure the initial visual state matches the checkbox.
    updateRoutine(item);
});


// ===============================
// FAVORITE ASSESSMENT
// ===============================

const favoriteButton =
    document.getElementById("favoriteButton");

favoriteButton.addEventListener("click", () => {
    const isFavorite =
        favoriteButton.classList.toggle("favorited");

    favoriteButton.setAttribute(
        "aria-pressed",
        String(isFavorite)
    );

    showMessage(
        isFavorite
            ? "Assessment added to favorites ⭐"
            : "Assessment removed from favorites."
    );
});


// ===============================
// SUPPORT BUTTONS
// ===============================

document.getElementById("supportButton")
    .addEventListener("click", () => {
        showMessage(
            "Support center selected. Connect your support service here."
        );
    });


document.getElementById("helpButton")
    .addEventListener("click", () => {
        showMessage(
            "If you are in immediate danger, contact local emergency services or a trusted person nearby."
        );
    });


// ===============================
// ASSESSMENT
// ===============================

document.getElementById("checkinButton")
    .addEventListener("click", () => {
        showMessage(
            "Check-in selected. Your assessment questions can open here."
        );
    });


document.getElementById("historyButton")
    .addEventListener("click", () => {
        showMessage(
            "Your previous check-ins will appear here when connected to your data."
        );
    });


// ===============================
// LANGUAGE BUTTON
// ===============================

document.getElementById("languageButton")
    .addEventListener("click", () => {
        showMessage(
            "Language selection: English / አማርኛ"
        );
    });


// ===============================
// ROUTINES AND BADGES
// ===============================

document.getElementById("routinesButton")
    .addEventListener("click", () => {
        showMessage(
            "Your complete daily routine list can open here."
        );
    });


document.getElementById("badgesButton")
    .addEventListener("click", () => {
        showMessage(
            "Your achievements and badges can appear here."
        );
    });


// ===============================
// COMMUNITY
// ===============================

document.getElementById("joinButton")
    .addEventListener("click", () => {
        showMessage(
            "Community selected. Connect your moderated discussion service here."
        );
    });


// ===============================
// GENERIC BUTTON INTERACTIONS
// ===============================

document.querySelectorAll("[data-message]")
    .forEach((button) => {
        button.addEventListener("click", () => {
            showMessage(button.dataset.message);
        });
    });


// ===============================
// BOTTOM NAVIGATION
// ===============================

const navigationItems =
    document.querySelectorAll(".nav-item");

navigationItems.forEach((item) => {

    item.addEventListener("click", () => {

        navigationItems.forEach((navItem) => {
            navItem.classList.remove("active");
        });

        item.classList.add("active");

        const page = item.dataset.page;

        if (page === "Home") {
            window.scrollTo({
                top: 0,
                behavior: "smooth"
            });

            return;
        }

        showMessage(
            page + " selected. Connect this button to the " +
            page.toLowerCase() + " page."
        );
    });

});


// ===============================
// INITIALIZATION
// ===============================

console.log("MindRise frontend loaded successfully!");